import { getStore, setStore } from '../../utils/store'

// import { getDictionary } from '@/projects/system/api/system/dict'

const dict = {
  state: {
    flowRoutes: getStore({ name: 'flowRoutes' }) || {}
  },
  actions: {
    //发送错误日志
    // FlowRoutes({ commit }) {
    //   return new Promise((resolve, reject) => {
    //     getDictionary({ code: 'flow' })
    //       .then(res => {
    //         commit('SET_FLOW_ROUTES', res.data.data)
    //         resolve()
    //       })
    //       .catch(error => {
    //         reject(error)
    //       })
    //   })
    // }
  },
  mutations: {
    SET_FLOW_ROUTES: (state, data) => {
      state.flowRoutes = data.map(item => {
        return {
          routeKey: `${item.code}_${item.dictKey}`,
          routeValue: item.remark
        }
      })
      setStore({ name: 'flowRoutes', content: state.flowRoutes })
    }
  }
}

export default dict
