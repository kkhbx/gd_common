import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import './permission' // 权限
import './error' // 日志
import './cache' // 页面缓存'
import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import './styles/common.scss'
import router from './router'
import store from './store'
import App from './App'
import request from './utils/axios'
import siberMenuConfig from './config/siber-menu.config'
// 引入通用功能
import { modularizeMethod, requestMethod } from '@modularize'
modularizeMethod(Vue)
requestMethod(Vue, request, require.context(`./api/modules`, true, /\.js$/))
Vue.use(router)
Vue.use(Vuex)
Vue.use(Element)
Vue.prototype.siberMenuConfig = siberMenuConfig
const startApp = () => {
  request.get('../static/common/config.json').then(res => {
    Vue.prototype.VUE_APP_BASE_API = res.ENV_CONFIG[process.env.NODE_ENV].ENV_LIST.VUE_APP_BASE_API
    axios.defaults.baseURL = Vue.prototype.VUE_APP_BASE_API
    // 设置各模块名
    const config = res.modules
    const configKeyList = Object.keys(config).filter(key => !key.startsWith('_'))
    if (configKeyList.length) {
      configKeyList.forEach(key => {
        const oConfig = config[key]
        Vue.prototype[key] = oConfig
      })
    }
    // const domain = getTopUrl()
    // info(domain).then(res => {
    //   const data = res.data
    //   if (data.success && data.data.tenantId) {
    //     Vue.prototype.website.tenantId = data.data.tenantId
    //     Vue.prototype.website.tenantMode = false
    //   }
    // })
    new Vue({
      el: '#app',
      router,
      store,
      render: h => h(App)
    })
  })
}

startApp()
