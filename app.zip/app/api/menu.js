import request from '../utils/axios'
import Vue from 'vue'
export const getList = (current, size, params) => {
  return request({
    url: Vue.prototype.system + '/menu/list',
    method: 'get',
    params: {
      ...params,
      current,
      size
    }
  })
}

export const getLazyList = (parentId, params) => {
  return request({
    url: Vue.prototype.system + '/menu/lazy-list',
    method: 'get',
    params: {
      ...params,
      parentId
    }
  })
}

export const getLazyMenuList = (parentId, params) => {
  return request({
    url: Vue.prototype.system + '/menu/lazy-menu-list',
    method: 'get',
    params: {
      ...params,
      parentId
    }
  })
}

export const getMenuList = (current, size, params) => {
  return request({
    url: Vue.prototype.system + '/menu/menu-list',
    method: 'get',
    params: {
      ...params,
      current,
      size
    }
  })
}

export const getMenuTree = tenantId => {
  return request({
    url: Vue.prototype.system + '/menu/tree',
    method: 'get',
    params: {
      tenantId
    }
  })
}

export const remove = ids => {
  return request({
    url: Vue.prototype.system + '/menu/remove',
    method: 'post',
    params: {
      ids
    }
  })
}

export const add = row => {
  return request({
    url: Vue.prototype.system + '/menu/submit',
    method: 'post',
    data: row
  })
}

export const update = row => {
  return request({
    url: Vue.prototype.system + '/menu/submit',
    method: 'post',
    data: row
  })
}

export const getMenu = id => {
  return request({
    url: Vue.prototype.system + '/menu/detail',
    method: 'get',
    params: {
      id
    }
  })
}

export const getRoutes = menuCode =>
  request({
    url: Vue.prototype.system + '/menu/routesByMenuCode',
    method: 'get',
    params: {
      menuCode
    }
  })

export const dictionary = code =>
  request({
    url: Vue.prototype.system + '/dict/dictionary',
    method: 'get',
    params: {
      code
    }
  })
