// approval模块
// API按模块统一规范
/**
 * @module name // 模块的名称,相当于方法名，命名方式建议当前模块名称+接口名称，避免命名重复的问题 必填
 * @method post/get // 请求方式 必填
 * @method desc // 接口简介 必填
 * @method path // 接口地址 必填
 * @method otherReauestParams // 其余参数 如header可以写为 otherReauestParams:{header: ''} f非必填
 */
// import Vue from 'vue'
// console.log(Vue.prototype.workflow, 'Vue.prototype.workflow')
export default [
  {
    name: 'ApprovalDoExport',
    method: 'post',
    desc: '查询导出',
    path: '/workflow/search/doExport',
    otherReauestParams: {
      responseType: 'blob'
    }
  },
  {
    name: 'statisticsWarning',
    method: 'get',
    desc: '综合受理',
    path: '/workflow/BpmInstLimitDate/statisticsWarning'
  },

  {
    name: 'saveDate',
    method: 'post',
    desc: '启动流程回调',
    path: '/workflow/SfXmsqxxb/saveDate'
  },

  {
    name: 'executeBiQuery',
    method: 'post',
    desc: '告知单查询详情',
    path: '/workflow/BiSearchdef/executeBiQuery'
  },
  {
    name: 'findByInstId',
    method: 'post',
    desc: '已受理查询详情',
    path: '/workflow/SfXmsqxxb/findByInstId'
  },
  {
    name: 'updateBpmInstLimitDateEntity',
    method: 'post',
    desc: '审批登记办理流程回调',
    path: '/workflow/SfXmsqxxb/updateBpmInstLimitDateEntity'
  },
  {
    name: 'addBusiness',
    method: 'post',
    desc: '审批登记办理流程回调',
    path: '/workflow/SfXmsqxxb/addBusiness'
  },
  {
    name: 'saveBsConstruction',
    method: 'post',
    desc: '办结回调',
    path: '/workflow/BsConstruction/save'
  },
  {
    name: 'ApprovalDoneTaskGroups',
    method: 'post',
    desc: '我的工作我的已办 办结',
    path: '/workflow/Searches/findDoneList'
  },
  // {
  //   name: 'ApprovalAttendsList',
  //   method: 'post',
  //   desc: '我的工作我的办结',
  //   path: '/workflow/myWork/attendsList'
  // },
  {
    name: 'ApprovalDoingTasks',
    method: 'post',
    desc: '我的工作我的待办',
    path: '/workflow/Searches/findUpcomingList'
  },
  {
    name: 'BsXzJfxqfindHandled',
    method: 'post',
    desc: '申请受理--已受理',
    path: '/workflow/BsXzJfxq/findHandled'
  },
  {
    name: 'BsXzJfxqfindUpcomingList',
    method: 'post',
    desc: '申请受理--窗口申请 网上受理',
    path: '/workflow/SfXmsqxxb/findList'
  },
  {
    name: 'findPending',
    method: 'post',
    desc: '网上受理 验收审批列表',
    path: '/workflow/SfJfsqysb/findPending'
  },
  {
    name: 'SfJfsqysbfindUpcomingList',
    method: 'post',
    desc: '申请受理--验收 -待办',
    path: '/workflow/SfJfsqysb/findUpcomingList'
  },
  {
    name: 'SfJfsqysbfindDoneList',
    method: 'post',
    desc: '申请受理--验收 -已办 办结',
    path: '/workflow/SfJfsqysb/findDoneList'
  },
  // 预选址 已办
  {
    name: 'yxzfindDoneList',
    method: 'post',
    desc: '',
    path: '/workflow/SfXzyssqb/findDoneList'
  },
  // 预选址 待办
  {
    name: 'yxzfindUpcomingList',
    method: 'post',
    desc: '',
    path: '/workflow/SfXzyssqb/findUpcomingList'
  },

  {
    name: 'ApprovalListByEntity',
    method: 'post',
    desc: '我的收藏案件',
    path: '/workflow/myCollect/listByEntity'
  },
  {
    name: 'ApprovalSynthesisAccept2',
    method: 'post',
    desc: '综合受理列表查询',
    path: '/workflow/synthesisAccept/listByEntity'
  },
  {
    name: 'ApprovalSaveAccept',
    method: 'post',
    desc: '综合受理新增',
    path: '/workflow/synthesisAcceptForm/save'
  },
  {
    name: 'ApprovalListByViewId',
    method: 'post',
    desc: '综合受理详情表单列表',
    path: '/workflow/synthesisAcceptForm/listByViewId'
  },
  {
    name: 'ApprovalUpdate',
    method: 'post',
    desc: '综合受理详情表单修改',
    path: '/workflow/synthesisAcceptForm/update'
  },
  {
    name: 'ApprovalGetData',
    method: 'post',
    desc: '综合受理详情查看',
    path: '/workflow/WfProBusPreview/getData'
  },
  {
    name: 'AcceptBusinessSearch',
    method: 'post',
    desc: '获取业务详情',
    path: '/workflow/SfCsxmsj/getOneByXmdm'
  },
  {
    name: 'ReportList',
    method: 'post',
    desc: '报件列表',
    path: '/workflow/ApplyTask/doingTasks'
  },
  {
    name: 'AcceptBusinessSave',
    method: 'post',
    desc: '业务登记',
    path: '/workflow/SfCsxmsj/save'
  },
  {
    name: 'toAccept',
    method: 'post',
    desc: '查询所有待受理',
    path: '/workflow/Workbench/findPending'
  },
  {
    name: 'toDo',
    method: 'post',
    desc: '查询所有待办',
    path: '/workflow/Workbench/listByEntity'
  },
  {
    name: 'businessStatistics',
    method: 'post',
    desc: '业务统计',
    path: '/workflow/Workbench/businessStatistics'
  },
  {
    name: 'taskStatistic',
    method: 'post',
    desc: '任务统计',
    path: '/workflow/Workbench/taskStatistic'
  },
  // 日程
  {
    name: 'listMyScheduleByDay',
    method: 'post',
    desc: '查询我的日程',
    path: '/workflow/BsXzSchedule/listByEntity'
  },
  {
    name: 'saveApSchedule',
    method: 'post',
    desc: '新增日程',
    path: '/workflow/BsXzSchedule/save'
  },
  {
    name: 'updateApSchedule',
    method: 'post',
    desc: '修改日程',
    path: '/workflow/BsXzSchedule/update'
  },
  {
    name: 'deleteApSchedule',
    method: 'post',
    desc: '删除日程',
    path: '/workflow/BsXzSchedule/delete'
  },
  {
    name: 'findByMonth',
    method: 'post',
    desc: '查询月日程',
    path: '/workflow/BsXzSchedule/findByMonth'
  },
  // 建房审批关联选址预审（1）
  {
    name: 'relevanceAddress',
    method: 'get',
    desc: '',
    path: '/workflow/SfXzyssqb/updateSummary11'
  },
  // 验收关联审批（2）
  {
    name: 'relevanceSp',
    method: 'get',
    desc: '',
    path: '/workflow/SfXmsqxxb/updateSummary11'
  },
  // 项目树
  {
    name: 'getAttProTreeTab',
    method: 'get',
    desc: '',
    path: '/workflow/zjdDir/getFileLessById'
  },
  // 生成文件
  {
    name: 'printToPDF',
    method: 'get',
    desc: '',
    path: '/workflow/print/printToPDF'
  },
  //
  {
    name: 'taskFormData',
    method: 'get',
    desc: '',
    path: '/workflow/smform/bpmFormView/taskFormData'
  }
]
