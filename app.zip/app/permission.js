/**
 * 全站权限配置
 *
 */
import router from './router'
import store from './store'
import Layout from './layout/index'
import { getToken } from './utils/auth'
import { Message } from 'element-ui'
import getDynamicRouter from '@modularize/util/dymamicRouting'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
NProgress.configure({ showSpinner: false })
router.beforeEach((to, from, next) => {
  const meta = to.meta || {}
  // const isMenu = meta.menu === undefined ? to.query.menu : meta.menu
  // store.commit('SET_IS_MENU', isMenu === undefined)
  if (getToken()) {
    // if (store.getters.isLock && to.path !== lockPage) {
    //   //如果系统激活锁屏，全部跳转到锁屏页
    //   next({ path: lockPage })
    // } else
    if (to.path === '/login') {
      //如果登录成功访问登录页跳转到主页
      next({ path: '/' })
    } else {
      //如果用户信息为空则获取用户信息，获取用户信息失败，跳转到登录页
      if (!store.getters.token || store.getters.token.length === 0) {
        store.dispatch('FedLogOut').then(() => {
          Message({ message: '用户信息获取失败，请重新登录', type: 'warning' })
          next({ path: '/login' })
        })
      } else {
        next()
      }
    }
  } else {
    //判断是否需要认证，没有登录访问去登录页
    if (meta.isAuth === false) {
      next()
    } else {
      if (to.path === '/login') {
        window.location.href = window.origin + (process.env.PRO_NAME ? '/' + process.env.PRO_NAME : '') + '/#/login'
        //如果登录成功访问登录页跳转到主页
        // next('/#/')
      } else {
        next('/login')
      }
    }
  }
})
router.onReady((to, from) => {
  store.dispatch('GetMenu', '0008').then(data => {
    router.addRoutes(getDynamicRouter(Layout, data, 'sysTest'))
    if (to.path === '/') {
      let paths = ''
      if (data.length !== 0) {
        if (data[0].children.length !== 0) {
          paths = data[0].children[0].path
        } else {
          paths = data[0].path
        }
      }
      router.push({ path: paths })
    } else {
      router.push({ path: to.path })
    }
  })
})
router.afterEach(() => {
  NProgress.done()
  // let title = store.getters.tag.label
  // let i18n = ''
  // if (store.getters.tag.meta) store.getters.tag.meta.i18n
  // title = router.$avueRouter.generateTitle(title, i18n)
  // //根据当前的标签也获取label的值动态设置浏览器标题
  // router.$avueRouter.setTitle(title)
})
